<html>
    <head>
    <?php include("headder.php"); ?>
        <title>BLOOD BANK</title>
        <link rel="stylesheet" href="log.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    </head>
    <body>
        <h2>BLOOD BANK</h2>

		<?php
			if(isset($_POST['sub']))
			{
			 
					$city=$_POST['city'];	
					$bank=$_POST['bank'];
					$group=$_POST['blood'];

					$link=mysqli_connect("localhost","id13212241_priyank","qGMOUQ|Ft7Bh=)Wg","id13212241_healthcare");

					$valquery = "select * FROM availability";
					$execute = mysqli_query($link,$valquery);
					while($row = $execute->fetch_assoc())
                    {
                        $city_db = $row["city"];
						$bank_db = $row["bank"];
						$group_db = $row["group"];
						//echo "$city_db, $bank_db,$group_db";

                        if($city==$city_db && $bank==$bank_db && $group==$group_db)
                        {
                           echo "<script type='text/javascript'> document.location = 'available.php';</script>";
                        }
                      
					}
					echo "<script type='text/javascript'> document.location = 'unavailable.php';</script>";
				}

		?>

        <form action="bloodbank.php" method="post">
            <div class="log">
            <h3>CITY </h3>
			<select name="city" style="height:40px;" id="1" onClick="yes()">
		<option value="" disabled selected hidden>Choose a City</option>
		<option value="Ahmedabad">Ahmedabad</option>
		<option value="Rajkot">Rajkot</option>
		<option value="Surat">Surat</option>
		<option value="Vadodara">Vadodara</option>
	</select>
	<br><br>
	<h3>BLOOD BANK</h3>
	<select name="bank" style="height:40px;" id="2">
	<option value="" disabled selected hidden>Choose Blood Bank</option>
	</select>

	<script type="text/javascript">

		function yes() {
			var x = $("#1 :selected").val();
			console.log(x);
			if(x == 'Ahmedabad')
			{
				$("#2").empty();
				var selectValues = {
				  "1": "Prathama Blood Centre",
				  "2": "Indian Red Cross Society",
				"3": "Lion's Blood Bank"
				};
				var $mySelect = $('#2');
				$.each(selectValues, function(key, value) {
				  var $option = $("<option/>", {
				    value: value,
				    text: value
				  });
				  $mySelect.append($option);
				});
			} else if(x == 'Rajkot') {
				$("#2").empty();
				var selectValues = {
				  "1": "Nathani Blood Bank",
				  "2": "Indian Red Cross Society",
				"3": "Field Marshal Blood Bank"
				};
				var $mySelect = $('#2');
				$.each(selectValues, function(key, value) {
				  var $option = $("<option/>", {
				    value: value,
				    text: value
				  });
				  $mySelect.append($option);
				});
			}
			else if(x == 'Surat') {
				$("#2").empty();
				var selectValues = {
				  "1": "Red Croos BLood Bank",
				  "2": "Lok Samarpan Blood Bank",
				"3": "Saraswat Bank"
				};
				var $mySelect = $('#2');
				$.each(selectValues, function(key, value) {
				  var $option = $("<option/>", {
				    value: value,
				    text: value
				  });
				  $mySelect.append($option);
				});
			}
			else{
				$("#2").empty();
				var selectValues = {
				  "1": "Indu Blood Bank",
				  "2": "Jalaram Blood Bank",
				"3": "Indian Red Cross Society"
				};
				var $mySelect = $('#2');
				$.each(selectValues, function(key, value) {
				  var $option = $("<option/>", {
				    value: value,
				    text: value
				  });
				  $mySelect.append($option);
				});
			}
		}
		</script>
                  <br><br>
                  <h3>BLOOD GROUP</h3>
                  <select name="blood" style="height:40px;" required>
                    <option value="" disabled selected hidden>Type of Blood</option>
                    <option value="A+">A+</option>
                    <option value="A-">A-</option>
                    <option value="AB+">AB+</option>
                    <option value="AB-">AB-</option>
                    <option value="B+">B+</option>
                    <option value="B-">B-</option>
                    <option value="O+">O+</option>
                    <option value="O-">O-</option>
                  </select>
            
                <br><br>
				<button type="submit" name="sub" value="SHOW AVAILABILITY">SHOW AVAILABILITY</button>
	</div>
              </form>
    </body>
</html>