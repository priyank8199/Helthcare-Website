<html>
<head>
    <?php include("headder.php"); ?>
    <link rel="stylesheet" href="project.css">

</head>
<body>
    <h2 style="text-align:center;">OUR MISSION</h2>
    <p style="text-align:center;">
        
        
Our project domain is “HEALTH CARE WEBSITE”. We have decided to make a health care Website as there are issues on not getting treatment or facilities on time and that can cause loss of lives. And our website also gives information about medicine, blood, and organ. NGO’s and health insurance are also connected to our website as NGO provides equipment’s like wheelchair, blood bank information, organ information and other things at subsidized rates. We visited hospital and saw there that a person was needing blood as he lost very much of blood as he meet with an accident. Our website will provide information about medicines whenever a person needs in emergency. Our website also provides information about diseases, its cure, symptoms, and their medicine.

</p>
<p style="text-align:center;">
We have made this project mainly for those who want details of the health care and those who want urgent blood, organ and other health related services through our website. Also, through our website doctors, NGO’s, Blood bank can also give blogs that would be helpful for the users.

    </p>


</body>
</html>