<html>
<head>
    <link rel="stylesheet" href="project.css">
    <style>
    body {font-family: Verdana, sans-serif; margin:0}
    </style>

</head>
<body>
<div class="header">
  <a href="index.php">
    <img src="logo.png" width="170" height="170">
  </a>
    <h1>HEALTHCARE WEBSITE</h1>
</div>
<div class="nav">
    <a href="index.php">HOME</a>
    <a href="about.php">ABOUT US</a>
    <a href="doctor.php">APPOINTMENT</a>
    <a href="bloodbank.php">BLOOD BANK</a>
    <a href="login.php" class="right">LOGIN/SIGN UP</a>

</div>

<div class="a">
    <h1>UNAVAILABLE</h1>
    <br>
    <br>
    <a href="bloodbank.php">SEARCH ANOTHER BLOODBANK</a>

</body>
</html>