<html>
    <head>
    <?php include("headder.php"); ?>
        <title>Appointment</title>
        <link rel="stylesheet" href="log.css">
    <style>
        h2{
            font-family: Arial, Helvetica, sans-serif;
            font-weight: bold;
            text-align: center;
        }
</style>
       
    </head>
    <body>
        <h2>Appointment</h2>

        <?php

         if(isset($_POST['sub']))
            {
                $randomnum= rand(1000,2000);
                $pna=$_POST["pna"];
                $email=$_POST["email"];
                $date=$_POST['appoint'];
                $time=$_POST['time'];

                $link=mysqli_connect("localhost","id13212241_priyank","qGMOUQ|Ft7Bh=)Wg","id13212241_healthcare");

                $querry="insert into doctor1(appointid,name,email,date,time) values('$randomnum','$pna','$email','$date','$time')";
                mysqli_query($link,$querry);
                if(isset($_POST['sub']))
                {
                    /*echo "<br> Successfull";*/
                    $mail_to=$_POST["email"];
                    $headers= "From :healthcare";
                    $txt = "Your appointment ID is: ".$randomnum."";
                    $sub = "Appointment";
                    mail($mail_to,$sub,$txt,$headers);
                    echo "<script type='text/javascript'> document.location ='index.php';</script>";
                    echo "success";
                }
                else
                {
                    echo "<br> Unsuccessfull";
                }
                $link->close();
            }
        ?>

        <form action="appoint.php" method="post">
            <div class="log">
            <h2> DR. MAHESH BHATT</h2><br>
            <label for="pna" ><b>ENTER PATIENT NAME</b></label><br>
                <input type="text" placeholder="PATIENT NAME" name="pna" required><br>
                <label for="email"><b>ENTER YOUR EMAIL</b></label><br>
                <input type="email" name="email"><br>
            <label for="appoint"><b>CHOOSE DATE</b></label><br>

            <input type="date" id="appoint" name="appoint"><br>

            <h4>CHOOSE TIME</h4>
            <select name="time">
		    <option value="" disabled selected hidden>Choose a Time</option>
		    <option value="10:00 am - 11:00 am">10:00 am - 11:00 am</option>
		    <option value="11:00 am - 12:00 pm">11:00 am - 12:00 pm</option>
		    <option value="12:00  pm - 1:00 pm">12:00  pm - 1:00 pm</option>
            <option value="5:00 pm - 6:00 pm">5:00 pm - 6:00 pm</option>
            <option value="6:00 pm - 7:00 pm">6:00 pm - 7:00 pm</option>
            <option value="7:00 pm - 8:00 pm">7:00 pm - 8:00 pm</option>
            </select>
            <br><br>
                
                    
                <button type="submit" name="sub" value="LOGIN">BOOK APPOINTMENT</button>

            </div>
           


        </form>
    </body>
</html>
