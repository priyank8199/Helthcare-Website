<html>
    <head>
    <?php include("headder.php"); ?>
    <title>Doctor profile</title>
    <style type="text/css">
        .main-box{
            border: 2px solid black;
            padding:0px;
            margin: auto;
            width: 700px;
            height: auto;    
            transition: all 0.5s;
            -webkit-box-shadow: -1px 1px 5px 4px rgba(0,0,0,0.75);
-moz-box-shadow: -1px 1px 5px 4px rgba(0,0,0,0.75);
box-shadow: -1px 1px 5px 4px rgba(0,0,0,0.75);
border-radius: 5px;
margin-bottom: 20px;
        }
        h1,h2{
            font-family: Arial, Helvetica, sans-serif;
            font-weight: bold;
            text-align: center;
        }
        .main-box.doctor_img  p{
            
        }
         img{
            float: left;
            margin:4px;
            
            padding: 4px;
        }
.main-box span {
  cursor: pointer;
  display: inline-block;
  position: relative;
  transition: 0.5s;
}

.main-box span:after {
  content: '\00bb';
  Font-size: 46px;
  position: absolute;
  opacity: 0;
  right: 15px;
  top: 70px;
  transition: 0.5s;
}

.main-box:hover span {
  padding-right: 20px;
}

.main-box:hover span:after {
    
    Font-size: 46px;
  top: 70px;
  opacity: 1;
  right: 15px;
}

.main-box input 
{
    font-family: Arial, Helvetica, sans-serif;
        font-size: 1.5em;
            font-weight: bold;
            text-align: center;
            color:#800080;
            padding: 5px 5px;
            margin: 5px 0px 0px 190px;
    border: 1px solid #FFFFFF;
    cursor:pointer;
}
      
    </style>
</head>
<body>
    <a href="appoint.php" name="sub"><div class="main-box">
        <span>
        <h1>SSC HOSPITAL</h1>
        <h2>DR. MAHESH BHATT</h2>
        <p style="text-align:center;">MBBS</p>
            <p>
                <img src="img_avatar3.png" alt="Doctor Image" height="100px" width="100px">
               <div class="info"> Dr. MAHESH BHATT is a senior doctor - practicing as a Consulting Physician, at SSG HOSPITAL, since last 32 years. He completed his M.B.B.S. from King Georges Medical College, Lucknow.  He has shined his academic career with Post Graduate Programme in Rheumatology, conducted by John Hopkins University School of Medicine, Baltimore, US. SSC Hospital has been enriched with his precious services at since last 32 years.
               </div>
            </p>
     
    </div></a>
    <a href="appoint1.php"><div class="main-box">
        <span>
        <h1>STERLING HOSPITAL</h1>
        <h2>DR. RAKESH SHAH</h2>
        <p style="text-align:center;">MD SURGEON</p>
            <p>
                <img src="img_avatar3.png" alt="Doctor Image" height="100px" width="100px">
               <div class="info"> Dr. RAKESH SHAH is a senior doctor - practicing as a Consulting Physician, at STERLING HOSPITAL, since last 25 years. He completed his M.B.B.S. from G.M.E.R.S, Gandhinagar. Then to satisfy his hunger of knowledge, he earned the degree of M.D. (Medicine)  from G.M.E.R.S, Gandhinaga. Sterling Hospital has been enriched with his precious services at since last 25 years
               </div>
            </p>
     
    </div></a>
    <a href="appoint2.php"><div class="main-box" onclick="appoint()">
        <span>
        <h1>BHAILAL AMIN</h1>
        <h2>DR. SURESH PATEL</h2>
        <p style="text-align:center;">MD ORTHOPEDIC</p>
            <p>
                <img src="img_avatar3.png" alt="Doctor Image" height="100px" width="100px">
               <div class="info"> Dr. SURESH PATEL is a senior doctor – critical care specialist, at BHAILAL AMIN Hospital, since last 30 years. He completed his M.B.B.S., in the year of 1981 from B. J. Medical College, Ahmedabad. Then to satisfy his hunger of knowledge, he earned the degree of M.D. (Internal Medicine) in the year of 1985 from B. J. Medical College, Ahmedabad. He has received special Training in Critical Care at N. H. Hospital, Mumbai. He has been also trained for ORTHOPEDIC from B. J. Medical College, Ahmedabad. Bhailal Amin Hospital has been enriched with his thriving practice since last 30 years.
               </div>
            </p>
     
    </div></a>
</span>
</body>
</html>